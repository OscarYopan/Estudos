import Home from './Home';
import About from './About';

export { Home, About };
