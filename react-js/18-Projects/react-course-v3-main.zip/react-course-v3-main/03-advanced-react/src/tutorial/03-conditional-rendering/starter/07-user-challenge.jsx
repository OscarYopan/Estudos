const UserChallenge = () => {
  return <h2>user challenge</h2>;
};

export default UserChallenge;
