const App = () => {
  return (
    <main>
      <h2>Slider Starter</h2>
    </main>
  );
};
export default App;
