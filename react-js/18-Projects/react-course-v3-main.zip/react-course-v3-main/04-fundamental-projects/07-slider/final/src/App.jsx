import Carousel from './Carousel';
import SlickCarousel from './SlickCarousel';

const App = () => {
  return (
    <main>
      <Carousel />
      {/* <SlickCarousel /> */}
    </main>
  );
};
export default App;
